package com.example.extrac;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.common.api.Status;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.widget.Autocomplete;
import com.google.android.libraries.places.widget.AutocompleteActivity;
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class AddExpenseActivity extends AppCompatActivity {

    private EditText inputTitle, inputAmount;
    private TextView textDate, textTime, textLocation;
    private Button btnSave, btnPickDate, btnPickTime, btnPickLocation;

    private static final int LOCATION_REQUEST_CODE = 202;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_expense);

        if (!Places.isInitialized()) {
            Places.initialize(getApplicationContext(), "AIzaSyDaHltQ9McGLdtCMGBuxBNWNc_RaI4m_FY");

        }

        bindViews();
        setListeners();
    }

    private void bindViews() {
        inputTitle = findViewById(R.id.inputTitle);
        inputAmount = findViewById(R.id.inputAmount);
        textDate = findViewById(R.id.textDate);
        textTime = findViewById(R.id.textTime);
        textLocation = findViewById(R.id.textLocation);
        btnSave = findViewById(R.id.btnSaveExpense);
        btnPickDate = findViewById(R.id.btnPickDate);
        btnPickTime = findViewById(R.id.btnPickTime);
        btnPickLocation = findViewById(R.id.btnPickLocation);
    }

    private void setListeners() {
        btnPickDate.setOnClickListener(v -> showDateDialog());
        btnPickTime.setOnClickListener(v -> showTimeDialog());
        btnPickLocation.setOnClickListener(v -> launchPlacePicker());
        btnSave.setOnClickListener(v -> recordExpense());
    }

    private void showDateDialog() {
        Calendar calendar = Calendar.getInstance();
        new DatePickerDialog(this, (view, year, month, day) -> {
            calendar.set(year, month, day);
            String dateStr = new SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(calendar.getTime());
            textDate.setText(dateStr);
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void showTimeDialog() {
        Calendar now = Calendar.getInstance();
        new TimePickerDialog(this, (view, hour, minute) -> {
            Calendar picked = Calendar.getInstance();
            picked.set(Calendar.HOUR_OF_DAY, hour);
            picked.set(Calendar.MINUTE, minute);
            String timeStr = new SimpleDateFormat("hh:mm a", Locale.getDefault()).format(picked.getTime());
            textTime.setText(timeStr);
        }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), false).show();
    }

    private void launchPlacePicker() {
        List<Place.Field> fields = Arrays.asList(Place.Field.ID, Place.Field.NAME, Place.Field.ADDRESS);
        Intent intent = new Autocomplete.IntentBuilder(AutocompleteActivityMode.OVERLAY, fields).build(this);
        startActivityForResult(intent, LOCATION_REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int reqCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(reqCode, resultCode, data);

        if (reqCode == LOCATION_REQUEST_CODE) {
            if (resultCode == RESULT_OK && data != null) {
                Place selectedPlace = Autocomplete.getPlaceFromIntent(data);
                textLocation.setText(selectedPlace.getName() + ", " + selectedPlace.getAddress());
            } else if (resultCode == AutocompleteActivity.RESULT_ERROR && data != null) {
                Status status = Autocomplete.getStatusFromIntent(data);
                Toast.makeText(this, "Error: " + status.getStatusMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void recordExpense() {
        String title = inputTitle.getText().toString().trim();
        String amountRaw = inputAmount.getText().toString().trim();
        String date = textDate.getText().toString();
        String time = textTime.getText().toString();
        String location = textLocation.getText().toString();

        if (title.isEmpty() || amountRaw.isEmpty() || date.isEmpty() || time.isEmpty()) {
            Toast.makeText(this, "Please complete all required fields", Toast.LENGTH_SHORT).show();
            return;
        }

        double amount;
        try {
            amount = Double.parseDouble(amountRaw);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid amount entered", Toast.LENGTH_SHORT).show();
            return;
        }

        new Thread(() -> {
           Database db = new Database(AddExpenseActivity.this);
            boolean inserted = db.addexpense(title, amount, date, time, location);

            runOnUiThread(() -> {
                if (inserted) {
                    Toast.makeText(this, "Expense recorded", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(this, "Failed to add expense", Toast.LENGTH_SHORT).show();
                }
            });
        }).start();
    }
}
