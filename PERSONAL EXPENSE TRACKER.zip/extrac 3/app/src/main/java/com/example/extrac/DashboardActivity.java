package com.example.extrac;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.ArrayList;

public class DashboardActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ExpenseAdapter adapter;
    private ArrayList<Expense> expenseList;
    private Database db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser == null) {
            startActivity(new Intent(this, SignInScreen.class));
            finish();
            return;
        }

        Log.d("DashboardActivity", "Current user UID: " + currentUser.getUid());


        recyclerView = findViewById(R.id.expenseRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));


        db = new Database(this);
        expenseList = new ArrayList<>();

        try {
            loadData();
        } catch (IllegalStateException e) {
            Log.e("DashboardActivity", "Error loading data: " + e.getMessage());
            Toast.makeText(this, "Could not load expenses. User not authenticated.", Toast.LENGTH_LONG).show();
        }


        adapter = new ExpenseAdapter(this, expenseList);
        recyclerView.setAdapter(adapter);
    }

    private void loadData() {
        Cursor cursor = db.readalldata();
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String title = cursor.getString(1);
                double amount = cursor.getDouble(2);
                String date = cursor.getString(3);
                String time = cursor.getString(4);
                String location = cursor.getString(5);

                expenseList.add(new Expense(id, title, amount, date, time, location));
            } while (cursor.moveToNext());
        }
        cursor.close();
    }
}
