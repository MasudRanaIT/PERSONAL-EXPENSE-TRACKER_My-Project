package com.example.extrac;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Database extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "expenses.db";
    private static final int DATABASE_VERSION = 2;
    private final Context context;
    private String tableName;

    public Database(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            this.tableName = "expenses_" + user.getUid();
        } else {
            Log.w("Database", "No user authenticated. Table name not set.");
        }
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (tableName != null) {
            db.execSQL("DROP TABLE IF EXISTS " + tableName);
            onCreate(db);
        }
    }

    private void ensureTableExists() {
        if (tableName == null) {
            throw new IllegalStateException("User is not authenticated. Cannot create or access table.");
        }

        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT name FROM sqlite_master WHERE type='table' AND name='" + tableName + "';";
        Cursor cursor = db.rawQuery(query, null);
        if (cursor.getCount() == 0) {
            String CREATE_TABLE = "CREATE TABLE " + tableName + " (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "title TEXT, " +
                    "amount REAL, " +
                    "date TEXT, " +
                    "time TEXT, " +
                    "location TEXT DEFAULT NULL)";
            db.execSQL(CREATE_TABLE);
            Log.d("Database", "Created table: " + tableName);
        }
        cursor.close();
    }

    public boolean addexpense(String title, double amount, String date, String time, String location) {
        if (tableName == null) {
            throw new IllegalStateException("User is not authenticated. Cannot add expense.");
        }

        ensureTableExists();

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("title", title);
        values.put("amount", amount);
        values.put("date", date);
        values.put("time", time);
        values.put("location", location);

        long result = -1;
        try {
            result = db.insertOrThrow(tableName, null, values);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            db.close();
        }

        return result != -1;
    }

    public Cursor readalldata() {
        if (tableName == null) {
            throw new IllegalStateException("User is not authenticated. Cannot read data.");
        }

        ensureTableExists();
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + tableName, null);
    }
}
