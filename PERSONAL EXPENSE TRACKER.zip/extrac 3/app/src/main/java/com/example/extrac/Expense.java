package com.example.extrac;

public class Expense {
    private int id;
    private String title;
    private double amount;
    private String date;
    private String time;
    private String location;


    public Expense(int id, String title, double amount, String date, String time, String location) {
        this.id = id;
        this.title = title;
        this.amount = amount;
        this.date = date;
        this.time = time;
        this.location = location;
    }


    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public double getAmount() {
        return amount;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public String getLocation() {
        return location;
    }
}
