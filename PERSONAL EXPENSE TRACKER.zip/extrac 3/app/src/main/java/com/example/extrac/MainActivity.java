package com.example.extrac;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Switch;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private DrawerLayout drawerLayout;
    private FirebaseAuth auth;
    private FirebaseUser user;
    private TextView userEmailText;
    private Switch themeSwitch;
    private NavigationView navView;

    private BarChart chart;
    private TableLayout tableLayout;

    private Database db;
    private ArrayList<Expense> expenseList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.d("MainActivity", "onCreate started");

        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();

        if (user == null) {
            Log.d("MainActivity", "User is not logged in, redirecting to SignInScreen");
            startActivity(new Intent(this, SignInScreen.class));
            finish();
            return;
        }

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawerLayout = findViewById(R.id.drawer_layout);
        navView = findViewById(R.id.navigation_view);
        navView.setNavigationItemSelectedListener(this);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar, R.string.open_drawer, R.string.close_drawer
        );
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        View headerView = navView.getHeaderView(0);
        userEmailText = headerView.findViewById(R.id.text_email);
        themeSwitch = headerView.findViewById(R.id.switch_theme_mode);

        userEmailText.setText(user.getEmail());

        headerView.findViewById(R.id.button_logout).setOnClickListener(v -> {
            Log.d("MainActivity", "Logging out user");
            auth.signOut();
            startActivity(new Intent(this, SignInScreen.class));
            finish();
        });

        themeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            Log.d("MainActivity", "Switching theme mode: " + (isChecked ? "Night Mode" : "Light Mode"));
            AppCompatDelegate.setDefaultNightMode(
                    isChecked ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO
            );
        });

        chart = findViewById(R.id.bar_chart);
        tableLayout = findViewById(R.id.expense_table);

        db = new Database(this);
        expenseList = new ArrayList<>();

        loadData();
        displayChartAndTable();
    }

    private void loadData() {
        Log.d("MainActivity", "Loading data from database...");
        Cursor cursor = db.readalldata();
        if (cursor != null && cursor.moveToFirst()) {
            Log.d("MainActivity", "Data loaded successfully");
            do {
                int id = cursor.getInt(0);
                String title = cursor.getString(1);
                double amount = cursor.getDouble(2);
                String date = cursor.getString(3);
                String time = cursor.getString(4);
                String location = cursor.getString(5);

                expenseList.add(new Expense(id, title, amount, date, time, location));
            } while (cursor.moveToNext());
            cursor.close();
        } else {
            Log.e("MainActivity", "No data found or error fetching data");
        }
    }

    private void displayChartAndTable() {
        Map<String, Double> dailyExpenses = new HashMap<>();
        for (Expense expense : expenseList) {
            String date = expense.getDate();
            double amount = expense.getAmount();
            dailyExpenses.put(date, dailyExpenses.getOrDefault(date, 0.0) + amount);
        }

        ArrayList<String> sortedDates = new ArrayList<>(dailyExpenses.keySet());
        Collections.sort(sortedDates);

        ArrayList<BarEntry> entries = new ArrayList<>();
        for (int i = 0; i < sortedDates.size(); i++) {
            String date = sortedDates.get(i);
            float total = dailyExpenses.get(date).floatValue();
            entries.add(new BarEntry(i, total));
        }

        boolean isDarkMode = (AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_YES);
        int textColor = isDarkMode ? Color.WHITE : Color.BLACK;

        BarDataSet dataSet = new BarDataSet(entries, "Total Daily Expenses");
        dataSet.setColor(getResources().getColor(R.color.colorPrimary));
        dataSet.setValueTextColor(textColor);
        BarData barData = new BarData(dataSet);
        barData.setBarWidth(0.9f);

        chart.setData(barData);
        chart.setFitBars(true);
        chart.getAxisLeft().setTextColor(textColor);
        chart.getAxisRight().setTextColor(textColor);
        chart.getLegend().setTextColor(textColor);
        chart.invalidate();

        XAxis xAxis = chart.getXAxis();
        xAxis.setGranularity(1f);
        xAxis.setGranularityEnabled(true);
        xAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                int index = (int) value;
                return (index >= 0 && index < sortedDates.size()) ? sortedDates.get(index) : "";
            }
        });
        xAxis.setTextColor(textColor);

        tableLayout.removeAllViews();

        TableRow headerRow = new TableRow(this);
        headerRow.setBackgroundColor(getResources().getColor(R.color.colorAccent));
        String[] headers = {"Title", "Cost", "Date"};

        for (String h : headers) {
            TextView textView = new TextView(this);
            textView.setText(h);
            textView.setTextColor(Color.BLACK);
            textView.setPadding(16, 8, 16, 8);
            textView.setBackgroundResource(R.drawable.table_border);
            headerRow.addView(textView);
        }
        tableLayout.addView(headerRow);

        for (Expense expense : expenseList) {
            TableRow row = new TableRow(this);
            row.setBackgroundResource(R.drawable.table_row_bg);

            TextView title = new TextView(this);
            title.setText(expense.getTitle());
            title.setTextColor(Color.BLACK);
            title.setPadding(16, 8, 16, 8);
            title.setBackgroundResource(R.drawable.table_border);
            row.addView(title);

            TextView amount = new TextView(this);
            amount.setText(String.format("%.2f", expense.getAmount()));
            amount.setTextColor(Color.BLACK);
            amount.setPadding(16, 8, 16, 8);
            amount.setBackgroundResource(R.drawable.table_border);
            row.addView(amount);

            TextView date = new TextView(this);
            date.setText(expense.getDate());
            date.setTextColor(Color.BLACK);
            date.setPadding(16, 8, 16, 8);
            date.setBackgroundResource(R.drawable.table_border);
            row.addView(date);

            tableLayout.addView(row);
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_dashboard) {
            startActivity(new Intent(this, DashboardActivity.class));
        } else if (id == R.id.nav_add_expense) {
            startActivity(new Intent(this, AddExpenseActivity.class));
        } else if (id == R.id.nav_stats) {
            startActivity(new Intent(this, StatsPage.class));
        }

        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }
}
