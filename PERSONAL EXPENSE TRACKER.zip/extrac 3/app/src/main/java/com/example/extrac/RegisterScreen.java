package com.example.extrac;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class RegisterScreen extends AppCompatActivity {

    private FirebaseAuth firebaseAuth;
    private TextInputEditText emailInput, passwordInput;
    private Button createAccountBtn;
    private ProgressBar loader;
    private TextView goToLoginLink;

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseUser sessionUser = FirebaseAuth.getInstance().getCurrentUser();
        if (sessionUser != null) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_register_screen);

        firebaseAuth = FirebaseAuth.getInstance();
        emailInput = findViewById(R.id.input_email);
        passwordInput = findViewById(R.id.input_password);
        createAccountBtn = findViewById(R.id.btn_create_account);
        goToLoginLink = findViewById(R.id.link_login);
        loader = findViewById(R.id.progress_loader);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (view, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            view.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        goToLoginLink.setOnClickListener(view -> {
            startActivity(new Intent(this, SignInScreen.class));
            finish();
        });

        createAccountBtn.setOnClickListener(view -> handleRegistration());
    }

    private void handleRegistration() {
        String email = emailInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();

        if (TextUtils.isEmpty(email)) {
            Toast.makeText(this, "Email cannot be empty", Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Password is required", Toast.LENGTH_SHORT).show();
            return;
        }

        loader.setVisibility(View.VISIBLE);

        firebaseAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    loader.setVisibility(View.GONE);
                    if (task.isSuccessful()) {
                        Toast.makeText(this, "Account successfully created!", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(this, SignInScreen.class));
                        finish();
                    } else {
                        Toast.makeText(this, "Failed to register. Try again.", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
