package com.example.extrac;

import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class StatsPage extends AppCompatActivity {

    private PieChart pieChart;
    private BarChart barChart;
    private Database db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stats);

        pieChart = findViewById(R.id.pieChart);
        barChart = findViewById(R.id.barChart);
        db = new Database(this);

        loadCharts();
    }

    private void loadCharts() {
        Cursor cursor = db.readalldata();
        Map<String, Double> categoryMap = new HashMap<>();

        if (cursor.moveToFirst()) {
            do {
                String title = cursor.getString(1);
                double amount = cursor.getDouble(2);
                categoryMap.put(title, categoryMap.getOrDefault(title, 0.0) + amount);
            } while (cursor.moveToNext());
        }
        cursor.close();

        ArrayList<PieEntry> pieEntries = new ArrayList<>();
        ArrayList<BarEntry> barEntries = new ArrayList<>();
        ArrayList<String> barLabels = new ArrayList<>();

        int index = 0;
        for (Map.Entry<String, Double> entry : categoryMap.entrySet()) {
            pieEntries.add(new PieEntry(entry.getValue().floatValue(), entry.getKey()));
            barEntries.add(new BarEntry(index, entry.getValue().floatValue()));
            barLabels.add(entry.getKey());
            index++;
        }

        boolean isDarkMode = (AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_YES);
        int textColor = isDarkMode ? Color.WHITE : Color.parseColor("#333333");

        int colorCount = categoryMap.size();
        ArrayList<Integer> dynamicColors = getColors(colorCount);


        PieDataSet pieDataSet = new PieDataSet(pieEntries, "Expense Categories");
        pieDataSet.setColors(dynamicColors);
        PieData pieData = new PieData(pieDataSet);
        pieData.setValueTextSize(14f);
        pieData.setValueTextColor(textColor);
        pieChart.setData(pieData);
        pieChart.setEntryLabelTextSize(12f);
        pieChart.setEntryLabelColor(textColor);
        pieChart.setUsePercentValues(true);
        pieChart.setCenterText("Expenses");
        pieChart.setCenterTextSize(18f);
        pieChart.setCenterTextColor(textColor);
        pieChart.getDescription().setEnabled(false);
        pieChart.getLegend().setTextColor(textColor);
        pieChart.animateY(1000);
        pieChart.invalidate();


        BarDataSet barDataSet = new BarDataSet(barEntries, "Expense Amounts");
        barDataSet.setColors(dynamicColors);
        BarData barData = new BarData(barDataSet);
        barData.setBarWidth(0.9f);
        barData.setValueTextSize(14f);
        barData.setValueTextColor(textColor);
        barChart.setData(barData);
        barChart.setFitBars(true);

        XAxis xAxis = barChart.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(barLabels));
        xAxis.setGranularity(1f);
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(false);
        xAxis.setLabelRotationAngle(-45);
        xAxis.setTextColor(textColor);

        barChart.getAxisLeft().setTextColor(textColor);
        barChart.getAxisRight().setTextColor(textColor);

        Description barDesc = new Description();
        barDesc.setText("Expenses by Category");
        barDesc.setTextColor(textColor);
        barChart.setDescription(barDesc);

        barChart.getLegend().setTextColor(textColor);
        barChart.animateY(1000);
        barChart.invalidate();
    }

    private ArrayList<Integer> getColors(int count) {
        ArrayList<Integer> colors = new ArrayList<>();
        float hueStep = 360f / count;

        for (int i = 0; i < count; i++) {
            float hue = i * hueStep;
            int color = Color.HSVToColor(new float[]{hue, 0.7f, 0.9f});
            colors.add(color);
        }

        return colors;
    }
}
